--
-- База данных: `test`
--

-- --------------------------------------------------------

--
-- Структура таблицы `articles`
--

CREATE TABLE `articles` (
  `id` int(11) NOT NULL,
  `root_partition` int(11) NOT NULL,
  `title` text COLLATE utf8_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `articles`
--

INSERT INTO `articles` (`id`, `root_partition`, `title`, `content`) VALUES
(1, 1, 'description', 'Крутой моцик!!!'),
(2, 2, 'description', '<h1>Статьи по ремонту и обслуживанию мотоцикла Motoland 250GS<h1>'),
(3, 5, 'Обслуживание первые 200 км.', 'менять масло, смазать цепь'),
(4, 5, 'Обслуживание первая 1000 км', 'Менять масло, смазать и подтянуть цепь, проверить спицы.'),
(6, 3, 'description', '<h1>Новости</h1>'),
(7, 4, 'description', '<h1>Фото, видео отчеты о мотоцикле Motoland 250GS</h1>');

-- --------------------------------------------------------

--
-- Структура таблицы `cats`
--

CREATE TABLE `cats` (
  `id` int(11) NOT NULL,
  `title` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `root` int(11) DEFAULT '-1',
  `txt` text CHARACTER SET utf8
) ENGINE=InnoDB DEFAULT CHARSET=cp1251;

--
-- Дамп данных таблицы `cats`
--

INSERT INTO `cats` (`id`, `title`, `root`, `txt`) VALUES
(1, 'Описание', 1, NULL),
(2, 'Характеристики', 1, NULL),
(3, 'Дизайн', 1, 'описание раздела'),
(4, 'Инструкция', 1, NULL),
(5, 'Обслуживание', 2, '<p>В данном разделе собраны материалы по ремонту и обслуживанию мотоцикла Motoland 250GS</p>\r\n<p>фото мотомастера</p>'),
(6, 'Двигатель', 2, NULL),
(7, 'Ходовая', 2, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `pages`
--

CREATE TABLE `pages` (
  `id` int(11) NOT NULL,
  `cat` int(11) NOT NULL,
  `header` varchar(250) DEFAULT NULL,
  `content` text
) ENGINE=InnoDB DEFAULT CHARSET=cp1251;

--
-- Дамп данных таблицы `pages`
--

INSERT INTO `pages` (`id`, `cat`, `header`, `content`) VALUES
(1, 4, 'заголовок', 'содержимое');

-- --------------------------------------------------------

--
-- Структура таблицы `static`
--

CREATE TABLE `static` (
  `id` varchar(15) NOT NULL,
  `content` text
) ENGINE=InnoDB DEFAULT CHARSET=cp1251;

--
-- Дамп данных таблицы `static`
--

INSERT INTO `static` (`id`, `content`) VALUES
('contacts', 'Контакты'),
('main', 'Главная страница'),
('prices', 'Прайс-листы');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `cats`
--
ALTER TABLE `cats`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `static`
--
ALTER TABLE `static`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `articles`
--
ALTER TABLE `articles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT для таблицы `cats`
--
ALTER TABLE `cats`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT для таблицы `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
